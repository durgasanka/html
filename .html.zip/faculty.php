<?php ?>
<html>
<head>
  <title>Faculty Info</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
  <script
  src="https://code.jquery.com/jquery-3.7.1.slim.js"
  integrity="sha256-UgvvN8vBkgO0luPSUl2s8TIlOSYRoGFAX4jlCIm9Adc="
  crossorigin="anonymous"></script>
  <script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
  <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Bricolage+Grotesque&family=Comic+Neue:wght@700&family=Inclusive+Sans&family=Satisfy&display=swap" rel="stylesheet">
  <style>
           body {
            font-family: 'Bricolage Grotesque', sans-serif;
			}
  </style>
</head>
<body>
<a href="index.php" style="text-decoration : none;padding : 20px;margin-top : 20px;">Go Home</a>
<div class="container-xxl py-5">
        <div class="container">
            <div class="text-center wow fadeInUp" data-wow-delay="0.1s" style="visibility: visible; animation-delay: 0.1s; animation-name: fadeInUp;">
                <h6 class="section-title bg-white text-center text-primary px-3">Instructors</h6>
                <h1 class="mb-5">Our Computer Science Faculty</h1>
            </div>
            <div class="row g-4">
                <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.1s" style="visibility: visible; animation-delay: 0.1s; animation-name: fadeInUp;">
                    <div class="team-item bg-light">
                        <div class="overflow-hidden">
                            <img class="img-fluid" src="https://vitap.ac.in/wp-content/uploads/2021/10/70351-Mr.-Gouranga-Mandal.jpg" alt="">
                        </div>
        
                        <div class="text-center p-4">
                            <h5 class="mb-0">Dr. Gouranga Mandal</h5>
                            <small><b>Specialization Areas</b>: Digital Image/Video Processing, Intelligent Transportation System, Artificial Intelligence, NLP, Pattern Recognition</small>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.3s" style="visibility: visible; animation-delay: 0.3s; animation-name: fadeInUp;">
                    <div class="team-item bg-light">
                        <div class="overflow-hidden">
                            <img class="img-fluid" src="https://vitap.ac.in/wp-content/uploads/2019/06/Mr.-HARI-KISHAN-KONDAVEETI.jpg" alt="">
                        </div>
                        
                        <div class="text-center p-4">
                            <h5 class="mb-0">Dr. K. Hari Kishan
                                </h5>
                            <small><b>Specialization Areas</b>: Digital Image Processing, Internet of Things, Remote Sensing</small>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.5s" style="visibility: visible; animation-delay: 0.5s; animation-name: fadeInUp;">
                    <div class="team-item bg-light">
                        <div class="overflow-hidden">
                            <img class="img-fluid" src="https://vitap.ac.in/wp-content/uploads/2023/06/manimaran-SCOPE.jpg" alt="">
                        </div>
                        
                        <div class="text-center p-4">
                            <h5 class="mb-0">Dr.S.Manimaran</h5>
                            <small><b>Specialization Areas</b>: Sensor-based Threats, Operating Systems, Blockchain, Internet of Things, and Deep Learning.</small>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.7s" style="visibility: visible; animation-delay: 0.7s; animation-name: fadeInUp;">
                    <div class="team-item bg-light">
                        <div class="overflow-hidden">
                            <img class="img-fluid" src="https://vitap.ac.in/wp-content/uploads/2022/10/Mr.Kareemulla-shaik.jpg" alt="">
                        </div>
                        
                        <div class="text-center p-4">
                            <h5 class="mb-0">Dr. Kareemulla Shaik</h5>
                            <small><b>Specialization Areas</b>: Wireless Networks and Security, Cyber Security, Machine Learning, Deep Learning and Internet of Things(IoT)</small>
                        </div>
                    </div>
                </div>
                <div class="row g-4">
                <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.1s" style="visibility: visible; animation-delay: 0.1s; animation-name: fadeInUp;">
                    <div class="team-item bg-light">
                        <div class="overflow-hidden">
                            <img class="img-fluid" src="https://vitap.ac.in/wp-content/uploads/2022/02/Dr-Arindam-Dey.jpg" alt="">
                        </div>
        
                        <div class="text-center p-4">
                            <h5 class="mb-0">Dr. Arindam Dey</h5>
                            <small><b>Specialization Areas</b>: Optimization problem, Genetic Algorithm, Fuzzy set & Fuzzy Logic, Artificial intelligence, Graph theory. </small>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.3s" style="visibility: visible; animation-delay: 0.3s; animation-name: fadeInUp;">
                    <div class="team-item bg-light">
                        <div class="overflow-hidden">
                            <img class="img-fluid" src="https://vitap.ac.in/wp-content/uploads/2022/04/Dr-Siddique-Ibrahim-Photo.jpg" alt="">
                        </div>
                        
                        <div class="text-center p-4">
                            <h5 class="mb-0">Dr. Siddique Ibrahim Peer Mohamed
                                </h5>
                            <small><b>Specialization Areas</b>: Data Science, Big Data Technologies, Artificial Intelligence, Machine Learning,Recommendation System</small>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.5s" style="visibility: visible; animation-delay: 0.5s; animation-name: fadeInUp;">
                    <div class="team-item bg-light">
                        <div class="overflow-hidden">
                            <img class="img-fluid" src="https://vitap.ac.in/wp-content/uploads/2019/06/Dr.-S.-SIBI-CHAKRAVARTY.jpg" alt="">
                        </div>
                        
                        <div class="text-center p-4">
                            <h5 class="mb-0">Dr.Sibi Chakkaravarthy.S</h5>
                            <small><b>Specialization Areas</b>: Cyber attacks and detection, Drone Security, Consumer Electronics Security</small>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.7s" style="visibility: visible; animation-delay: 0.7s; animation-name: fadeInUp;">
                    <div class="team-item bg-light">
                        <div class="overflow-hidden">
                            <img class="img-fluid" src="https://vitap.ac.in/wp-content/uploads/2022/10/Dr.Bommareddy-Lokesh.jpg" alt="">
                        </div>
                        
                        <div class="text-center p-4">
                            <h5 class="mb-0">Dr. Bommareddy Lokesh</h5>
                            <small><b>Specialization Areas</b>: Software-defined Networking, Network Function Virtualization, Datacenter Networks, Blockchain, and Data Analytics. </small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>