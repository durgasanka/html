<?php ?>
<html>
<head>
  <title>Facilities</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
  <script
  src="https://code.jquery.com/jquery-3.7.1.slim.js"
  integrity="sha256-UgvvN8vBkgO0luPSUl2s8TIlOSYRoGFAX4jlCIm9Adc="
  crossorigin="anonymous"></script>
  <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Bricolage+Grotesque&family=Comic+Neue:wght@700&family=Inclusive+Sans&family=Satisfy&display=swap" rel="stylesheet">
  <style>
           body {
            font-family: 'Bricolage Grotesque', sans-serif;
			}
            .facilities_list{
                padding : 30px;
            }
            .facilities_name{
                font-weight : bold;
            }
            .rating_summery_blk{
                margin-left: 100px;
                padding : 10px;
            }
            
  </style>
</head>
<body>
<a href="index.php" style="text-decoration : none;padding : 20px;margin-top : 20px;">Go Home</a>

<div class="facilities_list"><ul><li><div class="facilities_wrap"><span class="facilities_img"><img src="https://cache.careers360.mobi/images/frontend/desktop/facilities/boys-hostel.svg" alt="Boys Hostel" width="40" height="40"></span><span class="facilities_name">Boys Hostel</span></div><div id="" class=""><p dir="ltr">VIT- AP University boys hostel facilities include a gym, swimming pool, in-house sports amenities, first-aid centre, food outlets, mechanised laundry, outdoor stadium, study dormitories, general stores and many more.&nbsp;</p></div></li><li><div class="facilities_wrap"><span class="facilities_img"><img src="https://cache.careers360.mobi/images/frontend/desktop/facilities/girls-hostel.svg" alt="Girls Hostel" width="40" height="40"></span><span class="facilities_name">Girls Hostel</span></div><div id="" class=""><p dir="ltr">The university provides both AC and non-AC hostel rooms, equipped with a study table, chair, bed, cupboard and many more. The safety and security of the hostels is taken care of by the hostel wardens.</p></div></li><li><div class="facilities_wrap"><span class="facilities_img"><img src="https://cache.careers360.mobi/images/frontend/desktop/facilities/library.svg" alt="Library" width="40" height="40"></span><span class="facilities_name">Library</span></div><div id="" class=""><p dir="ltr">VIT- AP University include a large collection of textbooks, reference books, periodicals, national and international journals, periodicals, newspapers and magazines available in the library. The library also has many e-resources.</p></div></li><li><div class="facilities_wrap"><span class="facilities_img"><img src="https://cache.careers360.mobi/images/frontend/desktop/facilities/laboratories.svg" alt="Laboratories" width="40" height="40"></span><span class="facilities_name">Laboratories</span></div><div id="" class=""><p dir="ltr">VIT- AP University Amravati laboratory facilities include modern instruments and apparatus to help the students in practicals.</p></div></li><li><div class="facilities_wrap"><span class="facilities_img"><img src="https://cache.careers360.mobi/images/frontend/desktop/facilities/it-infrastructure.svg" alt="I.T Infrastructure" width="40" height="40"></span><span class="facilities_name">I.T Infrastructure</span></div><div id="" class=""><p dir="ltr">The university has a well-established IT Infrastructure for the students and faculty members. It controls and manages the networking of the entire campus.</p></div></li><li><div class="facilities_wrap"><span class="facilities_img"><img src="https://cache.careers360.mobi/images/frontend/desktop/facilities/cafeteria.svg" alt="Cafeteria" width="40" height="40"></span><span class="facilities_name">Cafeteria</span></div><div id="" class=""><p dir="ltr">VIT- AP University Amravati has a cafeteria that serves hygienically prepared fresh meals for the students and the staff members at reasonable prices.</p></div></li><li><div class="facilities_wrap"><span class="facilities_img"><img src="https://cache.careers360.mobi/images/frontend/desktop/facilities/transport.svg" alt="Transport Facility" width="40" height="40"></span><span class="facilities_name">Transport Facility</span></div><div id="" class=""><p dir="ltr">The University transport facilities include a fleet of buses. The buses ply between different parts of the city and the campus.</p></div></li><li><div class="facilities_wrap"><span class="facilities_img"><img src="https://cache.careers360.mobi/images/frontend/desktop/facilities/banks-facilities.svg" alt="Banks/ATMs" width="40" height="40"></span><span class="facilities_name">Banks/ATMs</span></div><div id="" class=""><p dir="ltr">VIT- AP University Amravati provides modern banking facilities for the students and staff members 24X7 ATM facility is also available.</p></div></li><li><div class="facilities_wrap"><span class="facilities_img"><img src="https://cache.careers360.mobi/images/frontend/desktop/facilities/hospital.svg" alt="Medical/Hospital" width="40" height="40"></span><span class="facilities_name">Medical/Hospital</span></div><div id="" class=""><p dir="ltr">The institute has an on-campus medical clinic. The clinic of the hospital provides basic first-aid treatment to the students and institute staff.</p></div></li><li><div class="facilities_wrap"><span class="facilities_img"><img src="https://cache.careers360.mobi/images/frontend/desktop/facilities/sports.svg" alt="Sports" width="40" height="40"></span><span class="facilities_name">Sports</span></div><div id="" class=""><p dir="ltr">VIT-AP University, Amaravati has a large sports ground that for which the students are encouraged to take part in various sports activities.&nbsp;</p></div></li><li><div class="facilities_wrap"><span class="facilities_img"><img src="https://cache.careers360.mobi/images/frontend/desktop/facilities/wifi.svg" alt="Wifi" width="40" height="40"></span><span class="facilities_name">Wifi</span></div><div id="" class=""><p dir="ltr">The university campus is enabled with Wi-Fi. Students and faculty members can access the facility at any time from anywhere inside the VIT-AP University campus.</p></div></li></ul></div>
<h4 style="margin-left : 55px">Student Rating About Our Facilities</h4>
<div class="rating_summery_blk"><div class="rating_bar bar"><div class="label">College Infrastructure<!-- -->: <strong>4.1<!-- -->/5</strong></div><div class="bars usageMeter"><meter min="0" max="50" value="41"></meter></div></div><div class="rating_bar bar"><div class="label">Academics<!-- -->: <strong>4.2<!-- -->/5</strong></div><div class="bars usageMeter"><meter min="0" max="50" value="42"></meter></div></div><div class="rating_bar bar"><div class="label">Placements<!-- -->: <strong>4.1<!-- -->/5</strong></div><div class="bars usageMeter"><meter min="0" max="50" value="41"></meter></div></div><div class="rating_bar bar"><div class="label">Value for Money<!-- -->: <strong>3.7<!-- -->/5</strong></div><div class="bars usageMeter"><meter min="0" max="50" value="37"></meter></div></div><div class="rating_bar bar"><div class="label">Campus Life<!-- -->: <strong>4.3<!-- -->/5</strong></div><div class="bars usageMeter"><meter min="0" max="50" value="43"></meter></div></div></div>
</html>
