<?php require_once 'admin/db_con.php'; ?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.0.0/animate.min.css"/>
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Bricolage+Grotesque&family=Comic+Neue:wght@700&family=Inclusive+Sans&family=Satisfy&display=swap" rel="stylesheet">
    
    <title>Home Page</title>
    <style>
        body{
          margin:0px;
          color : black;
                      font-family: 'Bricolage Grotesque', sans-serif;
                font-size : large;
        }
        .text{
                            font-size : large;

        }
        .container-fluid{
          background-color : gray;
          color : white;
          padding : 10px;
        }
.nav-link{
  color:white;
}

    a{
      text-decoration : none;
      background-color : gray: 
    }
    h2{
    }
    .container{
      font-size : small;
    }
      img{
        display : inline;
      }

      .text-center,.text-left{
        font-size : large
      }

      .desig{
          text-align : center;
      }
    </style>
  </head>
  <body>
  <nav class="navbar navbar-expand-lg bg-body-tertiary">
        <div class="container-fluid" >
          <a class="navbar-brand" style="color:white;margin-left : 10px" href="index.php">VIT - AP</a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" style="color : white;margin-left : 10px" id="navbarNav">
            <ul class="navbar-nav" style="color:white;">
             
              <li class="nav-item">
                <a class="nav-link " href="faculty.php">Faculty</a>
              </li>
              <li class="nav-item">
                <a class="nav-link " href="facilities.php">Facilities</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="about.php">About</a>
              </li>
            </ul>
          </div>
        </div>
      </nav>
    <div class="container">
      <img src="https://media.licdn.com/dms/image/C4D16AQEzCPpYOvTrfg/profile-displaybackgroundimage-shrink_350_1400/0/1641664721772?e=1700697600&v=beta&t=O5ljThwr9qgwxWo5757jTmAdaLV9mFjYcrhwoWGiM38"  alt="home-image" style="width:100%">
      <br>
      <br>
      <div class="in-focus" style="background:#FFFFFF; background-image:none;float:left;display : float;">  
      <section class="pages">           
    <div class="container">
                
        <div class="row">
                                    <div class="col-xl-6 col-sm-6 col-md-4">
                        <div class="news-list shadow margin-T30">
                            
                                <figure class="text-center" style="height: 50;margin-top : 10px;">
                                    <a href="https://vitap.ac.in/?post_type=post&amp;p=514">
                                        <img src="https://vitap.ac.in/wp-content/uploads/2020/12/Viswanthan-Sir.jpg" alt="" class="lazyloaded" style=" margin-top : 10px;" data-ll-status="loaded"><noscript><img src="https://vitap.ac.in/wp-content/uploads/2020/12/Viswanthan-Sir.jpg" alt=""></noscript></a></figure>
                            
                                <div class="news-list-content">
                                                                    <p class="desig">Dr. G. Viswanathan  <br> Founder &amp; Chancellor, VIT </p>
                                    <br>
</div>
</div>    
</section>          
    <div class="container">
        <div class="in-focus-wrap">    
            <div class="row">
                <div class="col-md-12">
                    <div class="in-focus-section ">
						<br>
							<h1 class="text-center sec_title"><i class="fa fa-camera" aria-hidden="true"></i> <a href="in-focuslist">News Briefing</a></h1>
						

            <div class="row">
                                                                                            
                    <div class="col-xl-12 col-sm-12 col-md-12 revealLeft" data-sr-id="2" style="; visibility: visible;  -webkit-transform: translateX(0) scale(1); opacity: 1;transform: translateX(0) scale(1); opacity: 1;-webkit-transition: -webkit-transform 0.5s cubic-bezier(0.6, 0.2, 0.1, 1) 0.2s, opacity 0.5s cubic-bezier(0.6, 0.2, 0.1, 1) 0.2s; transition: transform 0.5s cubic-bezier(0.6, 0.2, 0.1, 1) 0.2s, opacity 0.5s cubic-bezier(0.6, 0.2, 0.1, 1) 0.2s; "> 
                        <div class="shadow-2 margin-T20">   
                            
                            <div class="col-md-3 in-focus-item" style="background:#fff;">
                                <figure><a href=""><img src="https://vitap.ac.in/wp-content/uploads/2023/08/CEBlockchain-The-Hans-India.jpg" class="news-img" style="width:100%" alt="" class="lazyloaded" data-ll-status="loaded"><noscript><img src="https://vitap.ac.in/wp-content/uploads/2023/04/Hans_Vijayawada_21-03-2023-scaled.jpg" class="news-img" style="width:100%" alt=""></noscript></a></figure>
                            </div>
                            <div class="col-md-9">
                            <div class="infoc_title">
                            <h2 class="text-left" style="color: #fff;"><a href="underdev.php">About this News</a></h2>
                            </div> 
                              <div class="style-2" style="padding-top:1px;"> <p class="text" style="padding-top:1px;"> 
							  </p><p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p></div>
							   
                            </div>
							
							<div class="clearfix"></div>
                        </div>
						<div class="clearfix"></div>
                    </div>
                                                                                            
                    <div class="col-xl-12 col-sm-12 col-md-12 revealLeft" data-sr-id="3" style="; visibility: visible;  -webkit-transform: translateX(0) scale(1); opacity: 1;transform: translateX(0) scale(1); opacity: 1;-webkit-transition: -webkit-transform 0.5s cubic-bezier(0.6, 0.2, 0.1, 1) 0.2s, opacity 0.5s cubic-bezier(0.6, 0.2, 0.1, 1) 0.2s; transition: transform 0.5s cubic-bezier(0.6, 0.2, 0.1, 1) 0.2s, opacity 0.5s cubic-bezier(0.6, 0.2, 0.1, 1) 0.2s; "> 
                        <div class="shadow-2 margin-T20">   
                            
                            <div class="col-md-3 in-focus-item" style="background:#fff;">
                                <figure><a href=""><img src="https://vitap.ac.in/wp-content/uploads/2023/08/Independance-Day-Hans-India.jpeg" style="width:100%" class="news-img" alt="" class="lazyloaded" data-ll-status="loaded"><noscript><img src="https://vitap.ac.in/wp-content/uploads/2023/08/Independance-Day-Hans-India.jpeg" class="news-img" style="width:100%" alt=""></noscript></a></figure>
                            </div>
                            <div class="col-md-9">
                            <div class="infoc_title">
                            <h2 class="text-left" style="color: #fff;"><a href="underdev.php">More on this news</a></h2>
                            </div> 
                              <div class="style-2" style="padding-top:1px;"> <p class="text" style="padding-top:1px;"> 
							  </p><p style="text-align: justify;">Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source.</p></div>
							   
                            </div>
							
							<div class="clearfix"></div>
                        </div>
						<div class="clearfix"></div>
                    </div>
                                                                                            
                    <div class="col-xl-12 col-sm-12 col-md-12 revealLeft" data-sr-id="4" style="; visibility: visible;  -webkit-transform: translateX(0) scale(1); opacity: 1;transform: translateX(0) scale(1); opacity: 1;-webkit-transition: -webkit-transform 0.5s cubic-bezier(0.6, 0.2, 0.1, 1) 0.2s, opacity 0.5s cubic-bezier(0.6, 0.2, 0.1, 1) 0.2s; transition: transform 0.5s cubic-bezier(0.6, 0.2, 0.1, 1) 0.2s, opacity 0.5s cubic-bezier(0.6, 0.2, 0.1, 1) 0.2s; "> 
                        <div class="shadow-2 margin-T20">   
                            
                            <div class="col-md-3 in-focus-item" style="background:#fff;">
                                <figure><a href=""><img src="https://vitap.ac.in/wp-content/uploads/2023/06/Echo-Arunachal_04.06.2023.jpg" class="news-img" style="width:100%" alt="" class="lazyloaded" data-ll-status="loaded"><noscript><img src="https://vitap.ac.in/wp-content/uploads/2023/06/Echo-Arunachal_04.06.2023.jpg" class="news-img" style="width:100%" alt=""></noscript></a></figure>
                            </div>
                            <div class="col-md-9">
                            <div class="infoc_title">
                            <h2 class="text-left" style="color: #fff;"><a href="underdev.php">About this Paper</a></h2>
                            </div> 
                              <div class="style-2" style="padding-top:1px;"> <p class="text" style="padding-top:1px;"> 
							  </p><p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English.</p></div>
                              <div class="style-1">
<h2><strong>Why Prefer Our University?</strong></h2>
<ul class="list-group">
<li class="list-group-item">
<div id="vitffcs">&nbsp;<strong><i class="fa fa-book"></i>Unique Teaching-Learning Process</strong></div>
<p>With a focus on Engineering and Technology competencies, identified by industry and professional societies, the teaching learning process at VIT-AP prepares the students for the future. Based on a meticulously designed curriculum with industry and international academia feedback, the students are part of a flexible credit system where their learning is continuously assessed.</p></li>
<li class="list-group-item">
<div id="vitec"><i class="fa fa-universal-access"></i><strong>Fully Flexible Credit System (FFCS<sup><span style="font-size: 25px; vertical-align: middle;">®</span> </sup>)</strong></div>
<p>The students are offered a range of diverse courses, and provided the opportunity to select courses, timings and faculty members based on their aspirations and interests.</p></li>
<li class="list-group-item">
<div id="vitco-op">&nbsp;<i class="fa fa-cogs"></i><strong>Engineering Clinics</strong></div>
<p>We focus on practical learning, which involves the learners to apply classroom content to solve real-world problems. One of the key opportunities they are provided with is the Engineering Clinics where they put the concepts to use by creating contraptions. Students from different subject areas form their own groups, and with the help of a faculty coordinator, undertake projects where they apply knowledge gained from the classrooms.</p></li>
<li class="list-group-item">
<div id="vitsports">&nbsp;<i class="fa fa-chrome"></i><strong>Co-op Programmes and Internships</strong></div>
<p>Even before the students step out into the real world, we ensure they are industry -ready through our mandatory internships which are carried out as part of the programmes. The aim is to provide industrial exposure at an early stage in order to acquire a better understanding of the industry expectations.</p></li>
<li class="list-group-item">
<div id="vitcc"><i class="fa fa-futbol-o"></i><strong>Sports</strong></div>
<p>At VIT-AP, we believe that sound mental and good physical health are crucial for holistic development. With a strong emphasis on recreation of students, VIT-AP students, faculty and staff are provided facilities which keeps them active, spirited, involved, and healthy. Several intramural sports events are organised where students compete in cricket, badminton, volleyball, chess etc. Apart from intramural sports, different colleges and universities also participate in our in-house Sports and Cultural fest VITopia.</p></li>
<li class="list-group-item">
<div id="vitsp"><i class="fa fa-certificate"></i><strong>Clubs and Chapters</strong></div>
<p>At VIT-AP, there exists a symbiotic relationship between learning and enjoyment. With a stimulating community of students, various opportunities are provided to interact with students from diverse backgrounds. Several club activities eventually lead them to develop a crucial skillset comprising team-work, leadership, and event management.</p></li>
<li class="list-group-item">
<div id="vitip"><i class="fa fa-black-tie"></i><strong>&nbsp;Stellar Placements</strong></div>
<p>Seize the Unbeatable Placement Advantage [700+ companies, multiple offers]. At VIT-AP, students are part of serious and rigorous programmes which do not compromise on quality. As a result, they receive unparalleled placement opportunities through the well-connected placement cell.</p></li>
<li class="list-group-item">
<div id="vitcd">&nbsp;<strong><i class="fa fa-globe"></i>International Programmes</strong></div>
<p>International tie-ups have already resulted in several interactions with faculty from abroad such as Rochester Institute of Technology (USA) and Queensland University of Technology (Australia). Our international programmes are aimed at providing a global experience to the students with our SAP (Study Abroad Programmes) and ITP (International Transfer Programme-2 years abroad and 2 years at VIT-AP)<br>
Collaborative Masters + Doctoral level studies with international universities</p></li>
<li class="list-group-item">
<div id="vitfc">&nbsp;<i class="fa fa-twitter"></i><strong>Community Development</strong></div>
<p>The aim of reaching out to communities is to serve emerging rural needs, challenges, and help in social sustainability. It is also to promote sustainable rural development through participative planning, capacity building, effective networking, research and innovative efforts.</p></li>
<li class="list-group-item">
<div id="vitms">&nbsp;<i class="fa fa-android"></i> <strong>Infrastructure and Facilities</strong></div>
<p>Located at the heart of Amaravati, the capital of Andhra Pradesh, the institute is spread across 200 acres providing a comfortable and vibrant life on campus. In less than a year, our campus has two fully functional blocks, and three more coming up shortly. The aim is to create a green, educational and recreational space where learning is made meaningful and enjoyable.From digital library, well-equipped laboratories, health centre, cafeteria, bank and ATM, sports facilities, to a wi-fi enabled campus, the students are provided numerous superior facilities which are in line with global educational standards.</p></li>
<li class="list-group-item">
<div id="vitqf">&nbsp;<i class="fa fa-clock-o"></i> <strong>Mentoring Programme</strong></div>
<p>A unique mentoring programme is in place at our institute, where, a faculty member is assigned to a group of students as a mentor. The mentor not only helps a student in making informed decisions about his or her academic progress, but also acts as a local guardian.</p></li>
<li class="list-group-item">
<div id="vitel"><i class="fa fa-street-view"></i><strong>Qualified and Caring Faculty</strong></div>
<p>We have highly-qualified, experienced, committed and caring faculty to help students adjust to living and studying at VIT – AP. Our faculty members are well abreast with the current trends in Education and Technology and impart the same in classrooms and laboratories.<span style="color: #008000;"><strong>&nbsp;</strong></span></p></li>
<li class="list-group-item">
<div id="vitwc">&nbsp;<i class="fa fa-gg"></i><strong>Well-connected Alumni Network</strong></div>
<p>Being a VITian gives you an exclusive life-long opportunity of having a friend in most countries you go to and most companies you visit, and a mentor who can help you in time of need.</p></li>
</ul>
</div>
<br>
							  
                            </div>
                        </div>
						
                    </div>
                                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
    </div>
    <br>
    <script src="js/jquery-3.5.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
  </body>
</html>
